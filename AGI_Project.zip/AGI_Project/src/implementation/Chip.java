package implementation;

public class Chip {
	
	private Players player;
	
	public Chip(final Players player){
		this.player = player;
	}
}
