package implementation;

public interface FourWinsLogic {
	Results throwChip(Chip chip,int column);
}
