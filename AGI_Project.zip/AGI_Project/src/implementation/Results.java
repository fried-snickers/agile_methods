package implementation;

public enum Results {
ERROR, WIN, UNDECIDED, DRAW
}
