package implementation;

public enum Players {
PLAYER1, PLAYER2
}
